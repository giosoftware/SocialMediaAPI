const mongoose = require('mongoose');
const Schema = mongoose.Schema

groupSchema = new Schema({
    _id: {
        type: String,
        require: [true, 'El ID_GROUP es obligatorio.']
    },
    users: [{
        type: Number
    }]
});

userSchema = new Schema({
    _id: {
        type: Number,
        required: [true, 'El ID es obligatorio.']
    },
    password:{
        type:String,
        select:false,
        required:true
    },
    perfil: {
        name: {
            type: String,
            require: true
        },
        email: {
            type: String,
            require: true
        }
    },
    groups: [groupSchema],
    blocked: [{
        id: Number
    }]


});

// mongoose.model ('NOMBRE DE LA COLECCIÓN',commentSchema)
let User = mongoose.model('user', userSchema);
let Group = mongoose.model('group', groupSchema);

module.exports = {
    User,
    Group
}