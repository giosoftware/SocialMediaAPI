const mongoose = require('mongoose');
const Schema = mongoose.Schema

postSchema = new Schema({
    _id: {
        type: Number,
        required: [true, 'El ID_POST es obligatorio.']
    },
    idUser: {
        type: String,
        require: true
    },
    nameUser: {
        type: String,
        require: true
    },
    date: {
        type: Date,
        require: true
    },
    title: {
        type: String,
        require: true
    },
    text: {
        type: String,
        require: true
    },
    public: {
        type: Boolean,
        default: true
    },
    groups: [ 
        {
            type:String            
        }
    ],
    edited: {
        type: Boolean,
        default: false
    },
    date: {
        type: Date
    },
    deleted: {
        type: Boolean,
        default: false
    }

});

// mongoose.model ('NOMBRE DE LA COLECCIÓN',commentSchema)
let Post = mongoose.model('post', postSchema)

module.exports = {
    Post
}