const mongoose = require('mongoose');
const Schema = mongoose.Schema

commentSchema = new Schema({
    _id: {
        type: Number,
        required: [true, 'El ID_COMMENT es obligatorio.']
    },
    idPost: {
        type: Number,
        required: [true, 'El ID_POST es obligatorio.']
    },
    idUserComment: {
        type: Number,
        require: true
    },
    date: {
        type: Date,
        require: true
    },
    text: {
        type: String,
        require: true
    }
});

// mongoose.model ('NOMBRE DE LA COLECCIÓN',commentSchema)
let Comment = mongoose.model('comment', commentSchema)

module.exports = {
    Comment
}