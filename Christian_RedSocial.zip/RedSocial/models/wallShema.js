const mongoose = require('mongoose');
const Schema = mongoose.Schema;

commentWallSchema = new Schema({
    _id: {
        type: Number,
        required: [true, 'El ID_COMMENT es obligatorio.']
    },
    idPost: {
        type: Number,
        required: [true, 'El ID_POST es obligatorio.']
    },
    idUserComment: {
        type: Number,
        require: true
    },
    date: {
        type: Date,
        require: true
    },
    text: {
        type: String,
        require: true
    }
});

postWallSchema = new Schema({
    id: {
        type: Number,
        required: [true, 'El ID_POST es obligatorio.']
    },
    idUser: {
        type: String,
        require: true
    },
    nameUser: {
        type: String,
        require: true
    },
    date: {
        type: Date,
        require: true
    },
    title: {
        type: String,
        require: true
    },
    text: {
        type: String,
        require: true
    },
    public: {
        type: Boolean
    },
    groups: [{
        type: String
    }],
    edited: {
        type: Boolean
    },
    comments: [commentWallSchema]


});

wallSchema = new Schema({
    _id: {
        type: Number,
        required: [true, 'El ID_WALL es obligatorio.']
    },
    idUser: {
        type: Number,
        required: [true, 'El ID_USER es obligatorio.']
    },
    month: {
        type: Date,
        required: true
    },
    blocked: {
        type: Boolean,
        required: true
    },
    //POST PUBLICOS DE MIS CONTACTOS
    postmY: [{
        postWallSchema
    }],
    //POST PUBLICOS DE MIS CONTACTOS O DE CAULQUIER USUARIO
    postPublico: [{
        postWallSchema
    }]
});

// mongoose.model ('NOMBRE DE LA COLECCIÓN',commentSchema)
let Wall = mongoose.model('wall', wallSchema)

module.exports = {
    Wall
}