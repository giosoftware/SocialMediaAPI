'use strict';

const express = require('express');
const app = express();
const bodyParser = require('body-parser');

const IndexRoutes = require('./routes/indexRoutes');
const UserRoutes = require('./routes/userRoutes');
const PostRoutes = require('./routes/postRoutes');
const WallRoutes = require('./routes/wallRoutes');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));

app.use('/user', UserRoutes);
app.use('/post', PostRoutes);
app.use('/wall', WallRoutes);    // Wall / home(acceso/registro) -> si registro carga wall 
app.use('/', IndexRoutes);      // Wall / home(acceso/registro) -> si registro carga wall 

app.listen(3000);