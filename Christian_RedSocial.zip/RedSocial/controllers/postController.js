require('../config/connection.js')
const schema = require('../models/postSchema')
const Post = schema.Post

let postController = {
    index: (req, res) => {
        res.status(200).send('postController.index') ;  //Listado de Post
    },

    create: (req, res) => {
        res.status(200).send('postController.create') ; //Registro new post
    },

    delete: (req, res) => {
        res.status(200).send('postController.delete') ; //Delete post ¿en todo caso ocultarlo?
    },

    update: (req, res) => {
        res.status(200).send('postController.update') ; //Update post -> pendiente, no queda claro si se permitira modificar un post
    }
}

module.exports = postController