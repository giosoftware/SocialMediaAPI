require('../config/connection.js')
const schema = require('../models/wallShema')
const Wall = schema.Wall

let WallController = {
    show: (req, res) => {
        res.status(200).send('WallController.show') ;  //Info. por defecto (listado,home..)
    },
}

module.exports = WallController