const mongoose = require('mongoose')

mongoose.connect('mongodb://localhost:27017/RedSocial', {useNewUrlParser: true})
    .then(()=>console.log('connection established'))
    .catch(console.error.bind(console, 'error: '))

