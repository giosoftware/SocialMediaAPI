const express = require('express');
router = express.Router();

const wallController = require('../controllers/wallController');

//Los datos se envian en el "body" (id´s, ), por URL solo recibe "la ruta"

//WALL
    router.get('/',wallController.show);

module.exports = router