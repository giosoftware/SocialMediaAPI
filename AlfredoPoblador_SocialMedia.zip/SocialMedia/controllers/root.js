module.exports = class RootController {

    static showInfo(req, res) {
        const pjson = require('../package.json');
        res.json({ 
            name: pjson.name,
            description: pjson.description,
            version: pjson.version
        });
    }

}