module.exports = class UpdatePostController {
    
    static updatePost(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `updatePost for userid: ${req.params.userid} and PostId ${req.params.postid} not implemented`
        });
    }
}