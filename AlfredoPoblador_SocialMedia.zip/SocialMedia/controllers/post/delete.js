module.exports = class DeletePostController {
    
    static deletePost(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `deletePost for UserId: ${req.params.userid} not implemented` 
        });
    }
}