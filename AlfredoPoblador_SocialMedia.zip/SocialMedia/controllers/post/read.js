module.exports = class ReadPostController {

    static getAllPostsByUserId(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `getAllPostByUserId for UserId: ${req.params.userid} not implemented` 
        });
    }

    static getPostByUserIdPostId(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `getPostByUserIdPostId for UserId: ${req.params.userid} and PostId ${req.params.postid} not implemented` 
        });
    }
}