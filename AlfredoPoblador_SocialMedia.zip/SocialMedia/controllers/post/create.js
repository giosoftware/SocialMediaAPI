module.exports = class CreatePostController {
    
    static createPost(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `createPost for userid: ${req.params.userid} not implemented`
        });
    }
}