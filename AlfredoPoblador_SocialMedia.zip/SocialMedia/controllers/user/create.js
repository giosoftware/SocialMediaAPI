module.exports = class CreateUserController {
    
    static createUser(req, res) {
        res.status(501).json({ 
            status: 501,
            message: "createUser not implemented" 
        });
    }
}