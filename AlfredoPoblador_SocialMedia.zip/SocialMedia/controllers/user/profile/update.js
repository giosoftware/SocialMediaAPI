module.exports = class UpdateProfileController {
    
    static updateProfile(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `updateProfile for userid: ${req.params.userid} not implemented`
        });
    }
}