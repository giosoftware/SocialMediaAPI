module.exports = class ReadProfileController {

    static getProfileByUserId(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `getProfileByUserId for UserId: ${req.params.userid} not implemented` 
        });
    }
}