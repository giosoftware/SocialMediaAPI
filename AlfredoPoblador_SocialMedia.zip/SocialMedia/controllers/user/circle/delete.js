module.exports = class DeleteCircleController {
    
    static deleteCircle(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `deleteCircle for UserId: ${req.params.userid} and CircleId: ${req.params.circleid} not implemented` 
        });
    }
}