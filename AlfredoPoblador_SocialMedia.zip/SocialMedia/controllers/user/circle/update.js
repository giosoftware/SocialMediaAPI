module.exports = class UpdateCircleController {
    
    static updateCircle(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `updateCircle for userid: ${req.params.userid} and CircleId: ${req.params.circleid} not implemented`
        });
    }
}