module.exports = class CreateCircleController {
    
    static createCircle(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `createCircle for UserId: ${req.params.userid} not implemented` 
        });
    }
}