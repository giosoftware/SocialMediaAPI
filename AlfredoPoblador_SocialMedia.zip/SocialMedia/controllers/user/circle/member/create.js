module.exports = class CreateMemberController {
    
    static createMember(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `createMember for UserId: ${req.params.userid} and CircleId: ${req.params.circleid} not implemented` 
        });
    }
}