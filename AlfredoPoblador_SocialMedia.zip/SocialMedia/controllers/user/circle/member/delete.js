module.exports = class DeleteMemberController {
    
    static deleteMember(req, res) {
        res.status(501).json({ 
            status: 501,
            UserId: req.params.userid,
            CircleId: req.params.circleid,
            MemberId: req.params.memberid,
            message: `deleteMember not implemented` 
        });
    }
}