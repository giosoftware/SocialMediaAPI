module.exports = class ReadCirclesController {

    static getCirclesByUserId(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `getCirclesByUserId for UserId: ${req.params.userid} not implemented` 
        });
    }

}