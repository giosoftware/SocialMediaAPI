module.exports = class ReadUserController {

    static getUserByUserId(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `getUserByUserId for UserId: ${req.params.userid} not implemented` 
        });
    }
}