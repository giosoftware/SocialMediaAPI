module.exports = class ReadLockController {

    static getLocksByUserId(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `getLocksByUserId for UserId: ${req.params.userid} not implemented` 
        });
    }
}