module.exports = class CreateLockController {
    
    static createLock(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `createLock for UserId: ${req.params.userid} not implemented` 
        });
    }
}