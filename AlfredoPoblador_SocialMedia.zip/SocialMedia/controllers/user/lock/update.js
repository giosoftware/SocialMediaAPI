module.exports = class UpdateLockController {
    
    static updateLock(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `updateLock for userid: ${req.params.userid} and LockId: ${req.params.lockid} not implemented`
        });
    }
}