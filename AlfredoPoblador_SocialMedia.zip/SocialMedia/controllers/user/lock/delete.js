module.exports = class DeleteLockController {
    
    static deleteLock(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `deleteLock for UserId: ${req.params.userid} and LockId: ${req.params.lockid} not implemented` 
        });
    }
}