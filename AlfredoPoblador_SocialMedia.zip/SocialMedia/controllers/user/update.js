module.exports = class UpdateUserController {
    
    static updateUser(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `updateUser for userid: ${req.params.userid} not implemented`
        });
    }
}