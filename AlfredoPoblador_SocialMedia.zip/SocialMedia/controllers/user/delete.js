module.exports = class DeleteUserController {
    
    static deleteUser(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `deleteUser for UserId: ${req.params.userid} not implemented` 
        });
    }
}