module.exports = class ReadWallController {

    static getWallByUserIdYearMonth(req, res) {
        res.status(501).json({ 
            status: 501,
            year: Number.parseInt(req.params.year),
            month: Number.parseInt(req.params.month),
            message: `getWallByUserIdYearAndMonth for UserId: ${req.params.userid} not implemented` 
        });
    }
}