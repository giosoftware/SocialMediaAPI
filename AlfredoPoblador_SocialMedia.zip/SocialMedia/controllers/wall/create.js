module.exports = class CreateWallController {
    
    static createWall(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `createWall for userid: ${req.params.userid} not implemented`
        });
    }
}