module.exports = class UpdateWallController {
    
    static updateWall(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `updateWall for userid: ${req.params.userid} not implemented`
        });
    }
}