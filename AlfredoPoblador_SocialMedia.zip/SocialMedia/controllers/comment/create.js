module.exports = class CreateCommentController {
    
    static createCommentReplyComment(req, res) {
        res.status(501).json({ 
            status: 501,
            UserId: req.params.userid,
            CommentId: req.params.commentid,
            message: `createCommentReplyComment not implemented`
        });
    }

    static createCommentReplyPost(req, res) {
        res.status(501).json({ 
            status: 501,
            UserId: req.params.userid,
            PostId: req.params.postid,
            message: `createCommentReplyPost not implemented`
        });
    }

}