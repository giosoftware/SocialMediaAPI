module.exports = class ReadCommentController {

    static getCommentById(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `getCommentById for CommentId: ${req.params.commentid} not implemented` 
        });
    }

}