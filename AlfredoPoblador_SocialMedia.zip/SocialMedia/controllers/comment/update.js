module.exports = class UpdateCommentController {
    
    static updateComment(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `updateComment for CommentId: ${req.params.commentid} not implemented`
        });
    }
}