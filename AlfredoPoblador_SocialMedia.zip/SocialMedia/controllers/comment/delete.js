module.exports = class DeleteCommentController {
    
    static deleteComment(req, res) {
        res.status(501).json({ 
            status: 501,
            message: `deleteComment for UserId: ${req.params.userid} not implemented` 
        });
    }
}