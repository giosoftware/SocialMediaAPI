const mongoose = require('mongoose');
const Schema = mongoose.Schema;
let wallpostSchema = require('./schemas/wallpostSchema.js').wallpostSchema;

let wallSchema = new Schema({
    wallid: Number,
    userid: Number,
    year: Number,
    month: Number,    
    ownposts: [wallpostSchema],
    publicposts: [wallpostSchema],
    circleposts: [wallpostSchema],
    updated: Date
});

let Wall = mongoose.model('wall', wallSchema, 'wall');

module.exports = {Wall};