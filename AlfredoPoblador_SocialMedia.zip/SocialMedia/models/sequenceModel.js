const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let sequenceSchema = new Schema({
    _id: String,
    value: Number
});

let Sequence = mongoose.model('sequence', sequenceSchema, 'sequence');

module.exports = {Sequence};