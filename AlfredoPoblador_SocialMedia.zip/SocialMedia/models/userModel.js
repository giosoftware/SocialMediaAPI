const mongoose = require('mongoose');
const Schema = mongoose.Schema;
let lockSchema = require('./schemas/lockSchema.js').lockSchema;
let profileSchema = require('./schemas/profileSchema.js').profileSchema;
let circleSchema = require('./schemas/circleSchema.js').circleSchema;

let userSchema = new Schema({
    userid: Number,
    profile: profileSchema,
    locks: [lockSchema],
    locksme: [lockSchema],
    circles: [circleSchema]
});

let User = mongoose.model('user', userSchema, 'user');

module.exports = {User};