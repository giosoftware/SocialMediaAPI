const mongoose = require('mongoose');
const Schema = mongoose.Schema;
let bySchema = require('./schemas/bySchema.js').bySchema;
let replytoSchema = require('./schemas/replytoSchema.js').replytoSchema;

let commentSchema = new Schema({
    commentid: Number,
    postid: Number,
    by: bySchema,
    replyto: replytoSchema,
    text: String,
    updated: Date
});

let Comment = mongoose.model('comment', commentSchema, 'comment');

module.exports = {Comment, commentSchema};