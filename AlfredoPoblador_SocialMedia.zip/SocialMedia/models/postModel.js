const mongoose = require('mongoose');
const Schema = mongoose.Schema;
let bySchema = require('./schemas/bySchema.js').bySchema;
let commentSchema = require('./commentModel.js').commentSchema;
let circleSchema = require('./schemas/circleSchema.js').circleSchema;

let postSchema = new Schema({
    postid: Number,
    by: bySchema,
    circles: [circleSchema],
    public: Boolean,
    title: String,
    text: String,
    tags: [String],
    comments: [commentSchema],
    updated: Date
});

let Post = mongoose.model('post', postSchema, 'post');

module.exports = {Post};