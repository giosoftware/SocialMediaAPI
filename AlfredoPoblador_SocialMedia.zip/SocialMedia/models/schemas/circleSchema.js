const mongoose = require('mongoose');
const Schema = mongoose.Schema;
let memberSchema = require("./memberSchema.js").memberSchema;

let circleSchema = new Schema({
    circleid: Number,
    name: String,
    follower: Boolean,
    members: [memberSchema]
});

module.exports = {circleSchema};