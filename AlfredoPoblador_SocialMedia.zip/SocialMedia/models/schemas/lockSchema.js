const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let lockSchema = new Schema({
    userid: Number,
    name: String
});

module.exports = {lockSchema};