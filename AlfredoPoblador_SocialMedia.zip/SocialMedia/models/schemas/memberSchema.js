const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let memberSchema = new Schema({
    userid: Number,
    name: String
});

module.exports = {memberSchema};