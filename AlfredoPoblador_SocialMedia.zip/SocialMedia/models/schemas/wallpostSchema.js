const mongoose = require('mongoose');
const Schema = mongoose.Schema;
let bySchema = require('./bySchema.js').bySchema;
let commentSchema = require('../commentModel.js').commentSchema;

let wallpostSchema = new Schema({
    postid: Number,
    by: bySchema,
    public: Boolean,
    title: String,
    text: String,
    tags: [String],
    comments: [commentSchema],
    updated: Date
});

module.exports = {wallpostSchema};