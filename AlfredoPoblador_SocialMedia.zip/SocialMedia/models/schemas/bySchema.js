const mongoose = require('mongoose');
const Schema = mongoose.Schema;
let lockSchema = require('./lockSchema.js').lockSchema;

let bySchema = new Schema({
    userid: Number,
    name: String,
    locks: [lockSchema],
    locksme: [lockSchema]
});

module.exports = {bySchema};