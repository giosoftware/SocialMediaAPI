const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let replytoSchema = new Schema({
    commentid: Number,
    postid: Number
});

module.exports = {replytoSchema};