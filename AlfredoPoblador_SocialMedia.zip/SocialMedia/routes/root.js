const commentRoutes = require('./comment/comment.js');
const postRoutes = require('./post/post.js');
const userRoutes = require('./user/user.js');
const wallRoutes = require('./wall/wall.js');
const express = require('express');
const rootController = require('../controllers/root.js');
const router = express.Router();

router.use(express.static('public'));
router.use('/comments', commentRoutes);
router.use('/posts', postRoutes);
router.use('/users', userRoutes);
router.use('/walls', wallRoutes);

router.all('/', rootController.showInfo);

module.exports = router;