const createcommentController = require('../../controllers/comment/create.js');
const readcommentController = require('../../controllers/comment/read.js');
const updatecommentController = require('../../controllers/comment/update.js');
const deletecommentController = require('../../controllers/comment/delete.js');
const express = require('express');
const router = express.Router();

/**
 * @api {post} /comments/:userid/comment/:commentid Create a comment that reply another comment
 * @apiVersion 1.0.0
 * @apiName createCommentReplyComment
 * @apiGroup Comment
 * 
 * @apiParam {Number} userid Id of the user that creates the comment.
 * @apiParam {Number} commentid Id of the comment to be replied.
 * 
 */
router.post('/:userid/comment/:commentid', createcommentController.createCommentReplyComment);

/**
 * @api {post} /comments/:userid/post/:postid Create a comment that reply a post
 * @apiVersion 1.0.0
 * @apiName createCommentReplyPost
 * @apiGroup Comment
 * 
 * @apiParam {Number} userid Id of the user that creates the comment.
 * @apiParam {Number} postid Id of the post to be replied.
 *  
 */
router.post('/:userid/post/:postid', createcommentController.createCommentReplyPost);

/**
 * @api {get} /comments/:userid/:commentid Get comment by user and comment ids
 * @apiVersion 1.0.0
 * @apiName getCommentById
 * @apiGroup Comment
 * 
 * @apiParam {Number} userid Id of the user that owns the comment.
 * @apiParam {Number} commentid Id of the comment to obtain.
 *  
 */
router.get('/:userid/:commentid', readcommentController.getCommentById);

/**
 * @api {put} /comments/:userid/:commentid Update comment by user and comment ids
 * @apiVersion 1.0.0
 * @apiName updateComment
 * @apiGroup Comment
 * 
 * @apiParam {Number} userid Id of the user that owns the comment.
 * @apiParam {Number} commentid Id of the comment to update.
 *  
 */
router.put('/:userid/:commentid', updatecommentController.updateComment);

/**
 * @api {delete} /comments/:userid/:commentid Delete comment by user and comment ids
 * @apiVersion 1.0.0
 * @apiName deleteComment
 * @apiGroup Comment
 * 
 * @apiParam {Number} userid Id of the user that owns the comment.
 * @apiParam {Number} commentid Id of the comment to delete.
 *  
 */
router.delete('/:userid/:commentid', deletecommentController.deleteComment);

module.exports = router;