const createLockController = require('../../../controllers/user/lock/create.js');
const readLockController = require('../../../controllers/user/lock/read.js');
const updateLockController = require('../../../controllers/user/lock/update.js');
const deleteLockController = require('../../../controllers/user/lock/delete.js');
const express = require('express');
const router = express.Router();

router.post('/', createLockController.createLock);

router.get('/', readLockController.getLocksByUserId);

router.put('/:lockid', updateLockController.updateLock);

router.delete('/:lockid', deleteLockController.deleteLock);

module.exports = router;