const readProfileController = require('../../../controllers/user/profile/read.js');
const updateProfileController = require('../../../controllers/user/profile/update.js');
const express = require('express');
const router = express.Router();

router.get('/', readProfileController.getProfileByUserId);

router.put('/', updateProfileController.updateProfile);

module.exports = router;