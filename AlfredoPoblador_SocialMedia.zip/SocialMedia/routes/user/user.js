const createUserController = require('../../controllers/user/create.js');
const readUserController = require('../../controllers/user/read.js');
const updateUserController = require('../../controllers/user/update.js');
const deleteUserController = require('../../controllers/user/delete.js');
const profileRoutes = require('./profile/profile.js');
const lockRoutes = require('./lock/lock.js');
const circleRoutes = require('./circle/circle.js');
const express = require('express');
const router = express.Router();

router.use('/:userid/profile', profileRoutes);
router.use('/:userid/locks', lockRoutes);
router.use('/:userid/circles', circleRoutes);

router.post('/', createUserController.createUser);

router.get('/:userid', readUserController.getUserByUserId);

router.put('/:userid', updateUserController.updateUser);

router.delete('/:userid', deleteUserController.deleteUser);

module.exports = router;