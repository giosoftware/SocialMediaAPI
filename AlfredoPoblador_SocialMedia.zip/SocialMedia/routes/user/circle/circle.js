const createCircleController = require('../../../controllers/user/circle/create.js');
const readCircleController = require('../../../controllers/user/circle/read.js');
const updateCircleController = require('../../../controllers/user/circle/update.js');
const deleteCircleController = require('../../../controllers/user/circle/delete.js');
const memberRoutes = require('./member/member.js');
const express = require('express');
const router = express.Router();

router.use('/:circleid/members', memberRoutes);

router.post('/', createCircleController.createCircle);

router.get('/', readCircleController.getCirclesByUserId);

router.put('/:circleid', updateCircleController.updateCircle);

router.delete('/:circleid', deleteCircleController.deleteCircle);

module.exports = router;