const createMemberController = require('../../../../controllers/user/circle/member/create.js');
const readMemberController = require('../../../../controllers/user/circle/member/read.js');
const updateMemberController = require('../../../../controllers/user/circle/member/update.js');
const deleteMemberController = require('../../../../controllers/user/circle/member/delete.js');
const express = require('express');
const router = express.Router();

router.post('/', createMemberController.createMember);

router.get('/', readMemberController.getMembersByCircleIdUserId);

router.put('/:Memberid', updateMemberController.updateMember);

router.delete('/:Memberid', deleteMemberController.deleteMember);

module.exports = router;