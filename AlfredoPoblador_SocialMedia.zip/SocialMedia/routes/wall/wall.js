const createWallController = require('../../controllers/wall/create.js');
const readWallController = require('../../controllers/wall/read.js');
const updateWallController = require('../../controllers/wall/update.js');
const express = require('express');
const router = express.Router();

router.post('/:userid', createWallController.createWall);

router.get('/:userid/:year/:month', readWallController.getWallByUserIdYearMonth);

router.put('/:userid', updateWallController.updateWall);

module.exports = router;