const createPostController = require('../../controllers/post/create.js');
const readPostController = require('../../controllers/post/read.js');
const updatePostController = require('../../controllers/post/update.js');
const deletePostController = require('../../controllers/post/delete.js');
const express = require('express');
const router = express.Router();

router.post('/:userid', createPostController.createPost);

router.get('/:userid', readPostController.getAllPostsByUserId);

router.get('/:userid/:postid', readPostController.getPostByUserIdPostId);

router.put('/:userid/:postid', updatePostController.updatePost);

router.delete('/:userid/:postid', deletePostController.deletePost);

module.exports = router;