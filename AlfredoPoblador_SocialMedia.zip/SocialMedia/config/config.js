module.exports = class Config {

    static getConfig() {
        let envJSON = require('./env.variables.json');
        let node_env = process.env.NODE_ENV || 'development';
        return envJSON[node_env];
    }

}