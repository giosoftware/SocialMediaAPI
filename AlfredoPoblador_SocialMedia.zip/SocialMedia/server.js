const config = require('./config/config.js').getConfig();
const bodyParser = require('body-parser');
const rootRoutes = require('./routes/root.js');
const compression = require('compression');
const express = require('express');
const app = express();

app.use(compression());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));
app.use('/', rootRoutes);

app.listen(config.PORT);
console.log(`Server listening on port ${config.PORT}...`);