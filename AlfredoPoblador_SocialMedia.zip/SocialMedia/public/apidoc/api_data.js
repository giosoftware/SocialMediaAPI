define({ "api": [
  {
    "type": "post",
    "url": "/comments/:userid/comment/:commentid",
    "title": "Create a comment that reply another comment",
    "version": "1.0.0",
    "name": "createCommentReplyComment",
    "group": "Comment",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "userid",
            "description": "<p>Id of the user that creates the comment.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "commentid",
            "description": "<p>Id of the comment to be replied.</p>"
          }
        ]
      }
    },
    "filename": "./routes/comment/comment.js",
    "groupTitle": "Comment",
    "sampleRequest": [
      {
        "url": "http://localhost:3000/comments/:userid/comment/:commentid"
      }
    ]
  },
  {
    "type": "post",
    "url": "/comments/:userid/post/:postid",
    "title": "Create a comment that reply a post",
    "version": "1.0.0",
    "name": "createCommentReplyPost",
    "group": "Comment",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "userid",
            "description": "<p>Id of the user that creates the comment.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "postid",
            "description": "<p>Id of the post to be replied.</p>"
          }
        ]
      }
    },
    "filename": "./routes/comment/comment.js",
    "groupTitle": "Comment",
    "sampleRequest": [
      {
        "url": "http://localhost:3000/comments/:userid/post/:postid"
      }
    ]
  },
  {
    "type": "delete",
    "url": "/comments/:userid/:commentid",
    "title": "Delete comment by user and comment ids",
    "version": "1.0.0",
    "name": "deleteComment",
    "group": "Comment",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "userid",
            "description": "<p>Id of the user that owns the comment.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "commentid",
            "description": "<p>Id of the comment to delete.</p>"
          }
        ]
      }
    },
    "filename": "./routes/comment/comment.js",
    "groupTitle": "Comment",
    "sampleRequest": [
      {
        "url": "http://localhost:3000/comments/:userid/:commentid"
      }
    ]
  },
  {
    "type": "get",
    "url": "/comments/:userid/:commentid",
    "title": "Get comment by user and comment ids",
    "version": "1.0.0",
    "name": "getCommentById",
    "group": "Comment",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "userid",
            "description": "<p>Id of the user that owns the comment.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "commentid",
            "description": "<p>Id of the comment to obtain.</p>"
          }
        ]
      }
    },
    "filename": "./routes/comment/comment.js",
    "groupTitle": "Comment",
    "sampleRequest": [
      {
        "url": "http://localhost:3000/comments/:userid/:commentid"
      }
    ]
  },
  {
    "type": "put",
    "url": "/comments/:userid/:commentid",
    "title": "Update comment by user and comment ids",
    "version": "1.0.0",
    "name": "updateComment",
    "group": "Comment",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "userid",
            "description": "<p>Id of the user that owns the comment.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "commentid",
            "description": "<p>Id of the comment to update.</p>"
          }
        ]
      }
    },
    "filename": "./routes/comment/comment.js",
    "groupTitle": "Comment",
    "sampleRequest": [
      {
        "url": "http://localhost:3000/comments/:userid/:commentid"
      }
    ]
  },
  {
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "varname1",
            "description": "<p>No type.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "varname2",
            "description": "<p>With type.</p>"
          }
        ]
      }
    },
    "type": "",
    "url": "",
    "version": "0.0.0",
    "filename": "./public/apidoc/main.js",
    "group": "F__node_raul_Entrega_RedSocial_SocialMedia_public_apidoc_main_js",
    "groupTitle": "F__node_raul_Entrega_RedSocial_SocialMedia_public_apidoc_main_js",
    "name": ""
  }
] });
