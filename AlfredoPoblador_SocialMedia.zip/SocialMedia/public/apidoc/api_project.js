define({
  "name": "SocialMedia RESTful API",
  "version": "1.0.0",
  "description": "A SocialMedia RESTful API documentation",
  "sampleUrl": "http://localhost:3000",
  "template": {
    "forceLanguage": "en"
  },
  "order": [
    "Comment",
    "createCommentReplyComment",
    "createCommentReplyPost",
    "getCommentById",
    "updateComment",
    "deleteComment"
  ],
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-12-05T01:22:57.943Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
